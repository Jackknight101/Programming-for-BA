# BEMM458
code associated to BEMM458
please refer to the sessions folder



[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/thousandoaks/BEMM458/master)
